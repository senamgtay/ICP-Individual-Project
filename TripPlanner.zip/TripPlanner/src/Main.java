import java.io.*;
import java.lang.ArrayIndexOutOfBoundsException;
import java.util.*;

/**
 * @author Senam Glover-Tay
 * @version 1.0.3
 */
public class Main {

    //hashmap contains flight connections
    static HashMap<String, ArrayList<Routes>> flightmap = new HashMap<>();

    //reads the file and puts the data in a hashmap
    public static void readRoutes() throws FileNotFoundException {
        Scanner sc = new Scanner(new FileInputStream("routes.csv"));

        while (sc.hasNext()) {
            String line = sc.nextLine();
            String[] routeInfoArray = line.split(",");


            String newAirlineCode = routeInfoArray[0];
            String newStartAirportCode = routeInfoArray[2];
            String newEndAirportCode = routeInfoArray[4];
            int newstops = Integer.parseInt(routeInfoArray[7]);


            //creates new routeObject
            Routes routeObject = new Routes(newAirlineCode, newStartAirportCode, newEndAirportCode, newstops);

            String keystartcity = routeInfoArray[2];

            if (flightmap.containsKey(keystartcity)) {
                flightmap.get(keystartcity).add(routeObject);
            } else {
                ArrayList<Routes> routesOfAirport = new ArrayList<>();
                routesOfAirport.add(routeObject);
                flightmap.put(keystartcity, routesOfAirport);
            }

            //System.out.println(Routes.flightmap);
        }
        sc.close();
    }

    //performs the search to find the path
    public static boolean search(Airport initialAirport, Airport targetAirport) {

        String initialAirportCode = initialAirport.getIataCode();
        //if problem is goal test, return solution
        Queue<String> frontier = new LinkedList<>();
        frontier.add(initialAirportCode);

        HashSet<String> explored = new HashSet<String>();

        if (flightmap.containsKey(initialAirportCode)) {
            while (frontier.size() > 0) {
                String thisAirport = frontier.poll();
                explored.add(thisAirport);
                for (Routes rO : flightmap.get(thisAirport)) {
                   if (rO == null){
                       System.out.println("null found");
                        break;
                    }
                    System.out.println("next object looked at" + rO.getStartAirportCode());
                    if (!explored.contains(rO.getEndAirportCode()) && !frontier.contains(rO.getEndAirportCode())) {
                        if (rO.getEndAirportCode().equals(targetAirport.getIataCode())) {
                            return true; //solutionPath(initialAirport, rO);
                        }
                        frontier.add(rO.getEndAirportCode());

                    }
                }
            }

        }
        return false;
    }

    public static ArrayList<String> solutionPath(Airport initialAirport, Routes destination){
        ArrayList<String> solution = new ArrayList<>();

        while (!destination.getStartAirportCode().equals(initialAirport.getIataCode())){
            String thisAirline = destination.getAirlineCode();
            solution.add(thisAirline);
            String thisStart = destination.getStartAirportCode();
            solution.add(thisStart);
            String thisEnd = destination.getEndAirportCode();
            solution.add(thisEnd);
        }

        return null;
    }

    
    public static void main(String[]args) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader("sample input.txt"));
            String sourceAddress = reader.readLine();
            String destinationAddress = reader.readLine();
            System.out.printf("%s\n%s\n", sourceAddress, destinationAddress);

            Airport.filereader();
            ArrayList<Airport> possibleStartAirports = Airport.airportmap.get(sourceAddress);
            ArrayList<Airport> possibleEndAirports = Airport.airportmap.get(destinationAddress);


            Airport source = null;
            for (Airport airport : possibleStartAirports) {
                if (airport.getIataCode().equals("ACC")){
                    source = airport;
                }

            }
        Airport dest = null;
        for (Airport airport : possibleStartAirports) {
            if (airport.getIataCode().equals("ACC")){
                dest = airport;
            }

        }

            //Routes.readRoutes();
            //reader.close();
        readRoutes();
        System.out.println(source.toString() + dest.toString());
        System.out.println("Checking the search" + search(source,dest));

//        for(String key : flightmap.keySet()){
//           if(key.equals("ACC")){
//               System.out.println("Key found");
//           }
//
//        }

//        try {
//            FileWriter myWriter = new FileWriter("filename.txt");
//            myWriter.write(//solutionpath);
//            myWriter.close();
//            System.out.println("Check the file.");
//        } catch (IOException e) {
//            System.out.println("The task could not be completed.");
//            e.printStackTrace();
//        }
    }
        }





